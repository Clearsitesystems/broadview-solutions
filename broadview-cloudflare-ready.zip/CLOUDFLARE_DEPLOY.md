# Cloudflare Pages settings for this project
- Framework preset: None (Vite)
- Build command: npm run build
- Build output directory: dist
- Node version: 20 (set env NODE_VERSION=20 if needed)
- No environment variables required (Web3Forms key is baked into source).
The build runs scripts/bake-images.mjs first to download all images from Readdy
into public/readdy-assets, then runs `vite build`. After the first successful
build, the deployed site has no runtime dependency on Readdy.
